DROP TABLE IF EXISTS PREFIXiqit_elementor_landing;
DROP TABLE IF EXISTS PREFIXiqit_elementor_landing_lang;
DROP TABLE IF EXISTS PREFIXiqit_elementor_template;
DROP TABLE IF EXISTS PREFIXiqit_elementor_product;
DROP TABLE IF EXISTS PREFIXiqit_elementor_product_lang;

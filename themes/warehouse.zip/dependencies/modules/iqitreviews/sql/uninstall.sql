DROP TABLE PREFIXiqitreviews_products;


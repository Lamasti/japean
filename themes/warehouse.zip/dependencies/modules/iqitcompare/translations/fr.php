<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{iqitcompare}prestashop>iqitcompare_6fffbb6343db85dea6874e940b0a3b75'] = 'IQITCOMPARE';
$_MODULE['<{iqitcompare}prestashop>iqitcompare_497fa615ee083e46ef28a96310fb147e'] = 'Autoriser les clients à comparer les produits';
$_MODULE['<{iqitcompare}prestashop>actions_3d8073b0883c13a488004db4d16c204f'] = 'Produit supprimé';
$_MODULE['<{iqitcompare}prestashop>actions_c11e9db0f2e51467556def90d35c33ad'] = 'Tous les produits ont été supprimés';
$_MODULE['<{iqitcompare}prestashop>actions_65c727cbb872ca158a7b1b5ee7b7fa48'] = 'Produit ajouté au comparateur';
$_MODULE['<{iqitcompare}prestashop>comparator_ed203863f0a4ac73f521ec8f235453a8'] = 'Comparateur de produits';
$_MODULE['<{iqitcompare}prestashop>comparator_14380cb5fb4d995a5815e694013061a7'] = 'Supprimer tous les produits';
$_MODULE['<{iqitcompare}prestashop>comparator_ff9002208139901e2667d58c81d6f189'] = 'Aucun caractéristique à comparer';
$_MODULE['<{iqitcompare}prestashop>comparator_8bd65573745ac01c77e8d5d21f9cc713'] = 'Aucun produit à comparer';
$_MODULE['<{iqitcompare}prestashop>display-modal_b6e4507555ebfe6bd4b27b4cd3a95ebb'] = 'Produit ajouter à la comparaison';
$_MODULE['<{iqitcompare}prestashop>display-nav_7eece51cf3938103677db7a5051ef8f5'] = 'Comparer';
$_MODULE['<{iqitcompare}prestashop>product-miniature_7eece51cf3938103677db7a5051ef8f5'] = 'Comparer';
$_MODULE['<{iqitcompare}prestashop>product-page_aa1411cc44ecfafbca0d71427fe3dc7a'] = 'Ajouter à la comparaison';

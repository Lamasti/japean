 $("#cbp-hrmenu-tab-3 .nav-link .cbp-tab-title, #cbp-hrmenu-tab-3 .tabs-links, #cbp-hrmenu-tab-3 .cbp-categories-row").hover(
        function(){ // Mouse Over
            $("#cbp-hrmenu-tab-3 .nav-link .cbp-tab-title").parent().addClass("swapBg").find('img').attr('src','/img/cms/menu_femme_hover.png');
        },
        function(){ // Mouse Out
            $("#cbp-hrmenu-tab-3 .nav-link .cbp-tab-title").parent().removeClass("swapBg").find('img').attr('src','/img/cms/menu_femme.png');
        }
    );
$("#cbp-hrmenu-tab-2 .nav-link .cbp-tab-title, #cbp-hrmenu-tab-2 .tabs-links, #cbp-hrmenu-tab-2 .cbp-categories-row").hover(
        function(){ // Mouse Over
            $("#cbp-hrmenu-tab-2 .nav-link .cbp-tab-title").parent().addClass("swapBg").find('img').attr('src','/img/cms/menu_homme_hover.png');
        },
        function(){ // Mouse Out
            $("#cbp-hrmenu-tab-2 .nav-link .cbp-tab-title").parent().removeClass("swapBg").find('img').attr('src','/img/cms/menu_homme.png');
        }
    );
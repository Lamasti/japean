<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ph_relatedposts}prestashop>ph_relatedposts_3da9825931dabbd64e2cdde6cecd9511'] = 'Musisz posiadać zainstalowany moduł ph_simpleblog przed użyciem tego modułu';
$_MODULE['<{ph_relatedposts}prestashop>ph_relatedposts_c9c8c67d50c2cb79ca3b6d4a13c4f009'] = 'SimpleBlog - Powiązane Wpisy';
$_MODULE['<{ph_relatedposts}prestashop>ph_relatedposts_6aa1bc825bc7c74adf4b69e6fde94cc3'] = 'Widget do wyświetlania wpisów z modułu SimpleBlog powiązanych z wybranymi produktami';
$_MODULE['<{ph_relatedposts}prestashop>ph_relatedposts_d6f47e627cb8b9186caa435aba1c32ae'] = 'Na pewno usunąć?';
$_MODULE['<{ph_relatedposts}prestashop>ph_relatedposts_177f0eb97c41c1d839bff85af7cb1120'] = 'Powiązane Wpisy';
$_MODULE['<{ph_relatedposts}prestashop>adminsimpleblogrelatedpostscontroller_b77006f2d0398fa7e68ef1a893ef850c'] = 'ID Wpisu';
$_MODULE['<{ph_relatedposts}prestashop>adminsimpleblogrelatedpostscontroller_7ede3ad483a76ed293fdf6aa95596103'] = 'Tytuł wpisu';
$_MODULE['<{ph_relatedposts}prestashop>adminsimpleblogrelatedpostscontroller_97f08a40f22a625d0cbfe03db3349108'] = 'ID Produktu';
$_MODULE['<{ph_relatedposts}prestashop>adminsimpleblogrelatedpostscontroller_deb10517653c255364175796ace3553f'] = 'Nazwa produktu';
$_MODULE['<{ph_relatedposts}prestashop>adminsimpleblogrelatedpostscontroller_d3b206d196cd6be3a2764c1fb90b200f'] = 'Usuń zaznaczone';
$_MODULE['<{ph_relatedposts}prestashop>adminsimpleblogrelatedpostscontroller_e25f0ecd41211b01c83e5fec41df4fe7'] = 'Na pewno usunąć?';
$_MODULE['<{ph_relatedposts}prestashop>admin-tab_2e140652f28a5fbbc2a2d063f87c8ccb'] = 'Powiązane Wpisy';
$_MODULE['<{ph_relatedposts}prestashop>admin-tab_16d18932fb68f512e9a3d44943f8d431'] = 'Filtruj po tytule:';
$_MODULE['<{ph_relatedposts}prestashop>admin-tab_ec211f7c20af43e742bf2570c3cb84f9'] = 'Dodaj';
$_MODULE['<{ph_relatedposts}prestashop>admin-tab_1063e38cb53d94d386f21227fcd84717'] = 'Usuń';
$_MODULE['<{ph_relatedposts}prestashop>product-tab_177f0eb97c41c1d839bff85af7cb1120'] = 'Powiązane Wpisy';

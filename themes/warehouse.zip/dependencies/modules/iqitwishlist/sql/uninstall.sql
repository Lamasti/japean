DROP TABLE PREFIXiqitwishlist_product;

